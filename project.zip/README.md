# Soil Test Sheets (Rust app)

FDN field density test, lab compaction (MDD/OMC) and the Integration copy-across panel, packaged as a real app.
The app shell is **Rust (Tauri 2)**; the sheets are a web page shown by the device's webview.
Saved sheets and the autosaved draft stay on the device, inside the app.

## One-time setup (about 15 minutes)

1. Make a free GitHub account and a **public** repository (it only holds code, no data; it has to be public so free GitHub Pages can publish updates).
2. Upload everything in this folder to it (use a computer: phones often hide the `.github` folder, which has to come across).
3. **Keep the app updatable.** Repo **Settings > Secrets and variables > Actions > New repository secret**. Name: `DEBUG_KEYSTORE_B64`. Value: the whole text from `signing-key-secret.txt` (sent separately; keep it private, do not upload it into the repo). This makes every build use the same signing key, so a new APK installs over the old one and keeps your saved sheets.
4. **Turn on update publishing.** Repo **Settings > Pages > Source: GitHub Actions**. Then open **Actions > Publish app updates > Run workflow**. Your update address is `https://YOUR-USERNAME.github.io/YOUR-REPO/app.html`.
5. **Build the app.** **Actions > Build Android app > Run workflow**. After 10 to 20 minutes, download **soil-test-sheets-apk** from the finished run, unzip it, copy the `.apk` to your tablet and open it (Android asks once to allow installs from that source).
6. In the app: **Settings (gear) > App updates**, paste your update address, tap **Check for updates**. The address is remembered.

## Changing the sheets later (no new APK)

Replace `dist/app.html` in the repo with the new version. The Publish workflow runs by itself (about a minute). On the tablet: Settings > App updates > Check for updates. It downloads the new page, keeps it, and restarts.
If a downloaded update ever fails to start, the app drops it on the next launch and goes back to the built-in page. **Use built-in version** does the same on demand. Saved sheets are not touched either way.

A new APK is only needed for changes to the Rust shell, the icon, the app name or permissions.

## Build on your own computer instead

Needs Node 20+, Rust, Java 17 and the Android SDK/NDK (set `ANDROID_HOME`, `NDK_HOME`, `JAVA_HOME`).

```
npm install
npm run fonts          # downloads the fonts so the app works offline
npm run icons          # makes every icon size from app-icon.png
npm run dev            # desktop window
npm run android:init
npm run android:apk
```

## Where things are

- `dist/index.html`: tiny loader. Runs a downloaded update if there is one, otherwise `app.html`.
- `dist/app.html`: the sheets (built-in version, also what gets published for updates).
- `src-tauri/src/lib.rs`: the Rust app (window and commands the page can call).
- `src-tauri/tauri.conf.json`: app name, id (`au.soiltest.sheets`), window and icons.
- `.github/workflows/android.yml`: builds the APK. `.github/workflows/pages.yml`: publishes updates.
