//! Soil Test Sheets: the Rust side of the app.
//!
//! The sheets themselves (FDN test, lab compaction, Integration) are the web page in `dist/`,
//! shown by the system webview. Rust owns the app window, the Android/desktop packaging and the
//! commands the page can call. Saved sheets and the autosaved draft are kept by the webview's
//! local storage, which stays with the installed app on the device.

/// Lets the page show which build it is running in.
#[tauri::command]
fn app_version() -> String {
    env!("CARGO_PKG_VERSION").to_string()
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![app_version])
        .run(tauri::generate_context!())
        .expect("error while running Soil Test Sheets");
}
