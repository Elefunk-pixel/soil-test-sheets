#!/usr/bin/env bash
# Downloads the four font families the app uses, so it looks the same with no internet in the field.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p dist/fonts
T="$(mktemp -d)"
( cd "$T" && npm init -y >/dev/null && npm i --no-audit --no-fund \
    @fontsource/barlow @fontsource/barlow-semi-condensed @fontsource/ibm-plex-mono @fontsource/share-tech-mono >/dev/null )
cp "$T"/node_modules/@fontsource/barlow/files/barlow-latin-{400,500,600}-normal.woff2 dist/fonts/
cp "$T"/node_modules/@fontsource/barlow-semi-condensed/files/barlow-semi-condensed-latin-{600,700}-normal.woff2 dist/fonts/
cp "$T"/node_modules/@fontsource/ibm-plex-mono/files/ibm-plex-mono-latin-{400,500}-normal.woff2 dist/fonts/
cp "$T"/node_modules/@fontsource/share-tech-mono/files/share-tech-mono-latin-400-normal.woff2 dist/fonts/
rm -rf "$T"
echo "Fonts ready in dist/fonts"
